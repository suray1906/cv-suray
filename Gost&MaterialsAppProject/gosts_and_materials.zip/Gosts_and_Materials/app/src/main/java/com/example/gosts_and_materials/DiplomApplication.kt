package com.example.gosts_and_materials

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DiplomApplication: Application()