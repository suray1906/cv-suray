package com.example.gosts_and_materials.presentation.search.types.firmness

data class FirmnessState(
    val f_kod: String = "14",
    val type_id: String = "-1",
    val hb1: String = "",
    val hb2: String = ""
)