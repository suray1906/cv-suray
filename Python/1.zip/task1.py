from pandas import DataFrame
import numpy as np
import pandas as pd

data = pd.read_csv('HW.txt', sep = '\s+', header = 1, low_memory = False)

#print(data)

data.drop(index=data.index[-1], #удаляем ласт строку
        axis=0, 
        inplace=True)

d = {"EVENT": pd.Series(data['EVENT'], dtype = str, name = 'EVENT'),
     "AVG": pd.Series(data['AVGFULL'], dtype = int, name = 'AVG')
}
#print(d)

df1 = pd.DataFrame(d)

#print(df1)
#print(df1["EVENT"].unique()) only "ORDER"

result = { "EVENTNAME": 'ORDER',
    "min" : df1["AVG"].min(),
    "50%" : df1["AVG"].median(),
    "90%" : df1["AVG"].quantile(.9),
    "99%" : df1["AVG"].quantile(.99),
    "99.9%" : df1["AVG"].quantile(.999),
    
}

print(result)


rounded = []
for i in df1["AVG"]:
   rounded.append(round(i/5)*5) #округлем
   
from collections import Counter #словарь с отсортированными значениями и их кол-во
a = dict(Counter(rounded)) 
a = dict(sorted(a.items())) 
#print (a)


numbers = round(pd.Series(a.values(), dtype = int)/10000, 2)
#print(numbers)
for i in range(1, len(numbers)):
  numbers[i] = numbers[i-1] + numbers[i]
numbers = numbers.round(2)
#print(numbers)


d2 = { 
     "EXECTIME": pd.Series(a.keys(), dtype = int),
     "TransNO": pd.Series(a.values(), dtype = int),
     "Weight":  round(pd.Series(a.values(), dtype = int)/10000, 2), 
     "Percent": numbers,
}
print(d2)



