import tkinter as Tk
import numpy as np
import matplotlib
import dfsnsolver
import matplotlib.pyplot as plt
import matplotlib.animation as animation
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


def animheat(U, i):
    x = np.linspace(0, 2 * np.pi, int(N.get()))

    if i == 2:  # тепловая карта
        fig = plt.figure(1, figsize=(5, 5))
        fig.clf()
        ax3 = fig.add_subplot(111)
        c = plt.imshow(np.transpose(U), cmap=plt.get_cmap('plasma'))
        plt.colorbar(c)
        plt.title('Heat Map', fontweight="heavy")
        ax3.set_xlabel('t')
        ax3.set_ylabel('x')
        canvas = FigureCanvasTkAgg(fig, window)
        canvas.draw()
        canvas.get_tk_widget().grid(column=0, row=4, columnspan=8)

    elif i == 1:
        fig = plt.figure(1, figsize=(5, 5))
        fig.clf()
        ax1 = fig.add_subplot(111)
        line, = ax1.plot(x, U[0, :])

        def animate(i):
            line.set_ydata(U[i,:])
            return line,

        canvas = FigureCanvasTkAgg(fig, master=window)
        canvas.get_tk_widget().grid(column=0, row=4, columnspan=8)
        animotion = animation.FuncAnimation(fig, animate, np.arange(len(U)), interval=30, blit=False)
        canvas.draw()
    window.geometry('700x700')


def clicked():
    U = dfsnsolver.difffft(int(N.get()), int(M.get()), float(dt.get()), float(D.get()))
    animheat(U, selected.get())


window = Tk.Tk()
window.geometry('600x200')
window.title('RingDiffusion')

lbl = Tk.Label(window, text='Input N:')
lbl.grid(column=0, row=0, sticky=Tk.E)

N = Tk.StringVar()
txt = Tk.Entry(window, width=10, textvariable=N)
txt.grid(column=1, row=0, sticky=Tk.W, padx=10)
txt.focus()

lbl1 = Tk.Label(window, text='Input M:')
lbl1.grid(column=2, row=0, pady=10, sticky=Tk.E)

M = Tk.StringVar()
txt1 = Tk.Entry(window, width=10, textvariable=M)
txt1.grid(column=3, row=0, sticky=Tk.W, padx=10)

lbl2 = Tk.Label(window, text='Input D:')
lbl2.grid(column=4, row=0, pady=10, sticky=Tk.E)

D = Tk.StringVar()
txt2 = Tk.Entry(window, width=10, textvariable=D)
txt2.grid(column=5, row=0, sticky=Tk.W, padx=10)

lbl3 = Tk.Label(window, text='Input dt:')
lbl3.grid(column=6, row=0, pady=10, sticky=Tk.E)

dt = Tk.StringVar()
txt3 = Tk.Entry(window, width=10, textvariable=dt)
txt3.grid(column=7, row=0, sticky=Tk.W, padx=10)

selected = Tk.IntVar()
rad1 = Tk.Radiobutton(window, text='Animation', value=1, variable=selected)
rad1.grid(column=1, row=1, columnspan=2, sticky=Tk.E, padx=10, pady=10)
rad2 = Tk.Radiobutton(window, text='Heat Map', value=2, variable=selected)
rad2.grid(column=5, row=1, columnspan=2, sticky=Tk.E, padx=10, pady=10)

btn = Tk.Button(window, text="See", command=clicked, bg="blue", fg="white")
btn.grid(column=6, row=2, columnspan=2, sticky=Tk.E + Tk.W, pady=30, padx=10)

window.mainloop()
