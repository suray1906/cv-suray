import numpy as np


def difffft(N, M, dt, D):

    h = 2 * np.pi / N

    T = dt * M

    def F(um, tm):
        return np.sin(tm + 0.1 * um)

    lmbd = np.empty(N, dtype=float)
    for k in range(N // 2 + 1):
        lmbd[k] = (4 * D / (h ** 2)) * (np.sin(k * h / 4) ** 2)
        lmbd[-k] = lmbd[k]

    x = np.linspace(0, 2 * np.pi, N)
    Ul = np.empty((M, N), dtype=float)
    U = np.sin(5 * x)
    U0 = U
    Fu = np.fft.fft(U)
    Ul[0] = U0


    for m in range(1, M):
        t = m * dt
        tp = (m - 1) * dt
        F1 = F(U, tp)
        F2 = F(U, t)
        Us = U
        Fs = np.fft.fft((F1 + F2) / 2)
        for s in range(2):
            fourierUs = ((2 - dt * lmbd) * Fu + dt * Fs) / (2 + dt * lmbd)
            Us = np.fft.ifft(fourierUs)
            Fs = np.fft.fft((F1 + F(Us, t)) / 2)
            Fu = fourierUs
        Ul[m] = Us.real
        U = Us.copy()
    return Ul




